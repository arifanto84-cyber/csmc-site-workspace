CSMC Creative Agency — Cloudflare Pages package

Upload this ZIP using Cloudflare Pages Direct Upload.
The website entry point is index.html.

Steps:
1. Cloudflare Dashboard > Workers & Pages.
2. Create > Pages > Direct Upload.
3. Project name: csmc-creative-agency (if available).
4. Upload this ZIP.
5. Deploy.

Notes:
- The website itself is standalone: CSS, JavaScript, logo, portfolio, and other embedded assets are packaged inside index.html.
- External actions (WhatsApp, Google Maps, email, Instagram) require internet access.
- Do not place index.html inside another nested folder when manually extracting/re-zipping.
